<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
<a href="student_add">Add Student</a> </br> </br>
<?php echo e(session('msg')); ?>

<table id="customers">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th>Email</th>
            <th>Gpa</td>
            <th>Age</th> 
            <th>Gender</th> 
            <th>Action</th> 
            
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($list->id); ?></td>
            <td><?php echo e($list->name); ?></td>
            <td><?php echo e($list->created_at); ?></td>
            <td><?php echo e($list->updated_at); ?></td>
            <td><?php echo e($list->email); ?></td>
            <td><?php echo e($list->gpa); ?></td>
            <td><?php echo e($list->age); ?></td> 
            <td><?php echo e($list->gender); ?></td> 
            <td>
              <a href="student_edit/<?php echo e($list->id); ?>">Edit</a> &nbsp;
              <a href="student_delete/<?php echo e($list->id); ?>">Delete</a> &nbsp;
              
                          
            </td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
          
         

 </table>
<?php /**PATH C:\Users\97798\Desktop\student_management_system\resources\views/student_table.blade.php ENDPATH**/ ?>