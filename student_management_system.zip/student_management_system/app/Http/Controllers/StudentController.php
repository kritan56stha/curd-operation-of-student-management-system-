<?php

namespace App\Http\Controllers;

use App\Models\student;
use Illuminate\Http\Request;


class StudentController extends Controller
{
   
    public function index()
    {
       
    }

   
    public function create()
    {
        return View('student_add');
    }

   
    public function store(Request $request)
    {
        $data = new student;
        $data->name=$request->input('name');
        $data->email=$request->input('email');
        $data->gpa=$request->input('gpa');
        $data->age=$request->input('age');
        $data->gender=$request->input('gender');
        $data->save();
        $request->session()->flash('msg','New Student Add Successfully');
        return redirect ('student_show');
       
    }

   
    public function show(student $student)

    {
        return View('student_table')->with('data',student::all());
       
    }

    
    public function edit(student $student,$id)
    {

        return View('student_edit')->with('data',student::find($id));


        
    }

    
    public function update(Request $request, student $student)
    {
        $data =  student::find($request->id);
        $data->name=$request->input('name');
        $data->email=$request->input('email');
        $data->gpa=$request->input('gpa');
        $data->age=$request->input('age');
        $data->gender=$request->input('gender');
        $data->save();
        $request->session()->flash('msg','updated Successfully');
        return redirect ('student_show');
       
    }

   
    public function destroy(student $student,$id)
    {
        student::destroy(array('id',$id));
        return redirect('student_show');


        
    }
}
