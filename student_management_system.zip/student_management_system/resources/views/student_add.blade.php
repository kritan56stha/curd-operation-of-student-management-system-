<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
<a href="student_show">Back</a> </br> </br>
<form method="post" action="add_student">
    @csrf
    <table  align=center cellspacing=10 id="customers">
        <tr>
          <td>Name</td>
          <td><input type="textbox" name="name" placeholder="Name" required></td> 
        </tr>
        <tr>
          <td>Email</td>
          <td><input type="textbox" name="email" placeholder="email" required></td> 
    
        </tr>
       
        <tr>
          <td>Gpa</td>
          <td><input type="textbox" name="gpa" placeholder="Gpa" required></td> 
    
        </tr>

        <tr>
            <td>Age</td> </br>
            <td><input type="textbox" name="age"  placeholder="Age" required></td> 
        </tr>
        <tr>
            
            <td>Gender</td> </br>
            <td><input type="textbox" name="gender"  placeholder="Gender" required></td> 

        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="submit" ></td>

        </tr>

    </table>
</form>

