<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
<a href="student_add">Add Student</a> </br> </br>
{{session('msg')}}
<table id="customers">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th>Email</th>
            <th>Gpa</td>
            <th>Age</th> 
            <th>Gender</th> 
            <th>Action</th> 
            
        </tr>
        @foreach($data as $list)
        <tr>
            <td>{{$list->id}}</td>
            <td>{{$list->name}}</td>
            <td>{{$list->created_at}}</td>
            <td>{{$list->updated_at}}</td>
            <td>{{$list->email}}</td>
            <td>{{$list->gpa}}</td>
            <td>{{$list->age}}</td> 
            <td>{{$list->gender}}</td> 
            <td>
              <a href="student_edit/{{$list->id}}">Edit</a> &nbsp;
              <a href="student_delete/{{$list->id}}">Delete</a> &nbsp;
              
                          
            </td>
            
        </tr>
        @endforeach
        
          
         

 </table>
